package com.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.DAO.MedicineDao;
import com.project.entity.Medicine;

@Service
public class MedicineServiceImpl implements MedicineService {
	@Autowired
	MedicineDao medicineDao;
	public List<Medicine> getAllMedicines() {
		// TODO Auto-generated method stub
		return medicineDao.getAllMedicines();
	}

	public void saveMedicine(Medicine theMedicine) {
		// TODO Auto-generated method stub
		 medicineDao.saveMedicine(theMedicine);
	}

	public Medicine getMedicine(int theId) {
		// TODO Auto-generated method stub
		return medicineDao.getMedicine(theId);
	}

	public void deleteMedicine(int theId) {
		// TODO Auto-generated method stub
		medicineDao.deleteMedicine(theId);
	}

	@Override
	public Medicine findMedicine(int theId) {
		medicineDao.findMedicine(theId);
		return null;
	}

}
