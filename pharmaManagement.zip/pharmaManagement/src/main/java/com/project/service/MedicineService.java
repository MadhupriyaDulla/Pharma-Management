package com.project.service;

import java.util.List;

import com.project.entity.Medicine;

public interface MedicineService {

	List<Medicine> getAllMedicines();

	void saveMedicine(Medicine theMedicine);

	Medicine getMedicine(int theId);

	void deleteMedicine(int theId);

	Medicine findMedicine(int theId);



}
