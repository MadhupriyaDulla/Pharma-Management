package com.project.entity;



import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Medicine")
public class Medicine {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Id")
private int Id;
	@Column(name="TypeOfMedicine")
	private String TypeOfMedicine;
	@Column(name="Name")
private String Name;
	@Column(name="Price")
private String Price;
    @Column(name="Manufacturer")
    private String Manufacturer;
	@Column(name="DateOFManufature")
private Date DateOfManufacture;
	@Column(name = "ExpiryDate")
	private Date ExpiryDate;

public Medicine()
{}

public Medicine( String typeOfMedicine, String name, String price, String manufacturer, Date dateOfManufacture,
		Date expiryDate) {
	

	TypeOfMedicine = typeOfMedicine;
	Name = name;
	Price = price;
	Manufacturer = manufacturer;
	DateOfManufacture = dateOfManufacture;
	ExpiryDate = expiryDate;
}

public int getId() {
	return Id;
}

public void setId(int id) {
	Id = id;
}

public String getTypeOfMedicine() {
	return TypeOfMedicine;
}

public void setTypeOfMedicine(String typeOfMedicine) {
	TypeOfMedicine = typeOfMedicine;
}

public String getName() {
	return Name;
}

public void setName(String name) {
	Name = name;
}

public String getPrice() {
	return Price;
}

public void setPrice(String price) {
	Price = price;
}

public String getManufacturer() {
	return Manufacturer;
}

public void setManufacturer(String manufacturer) {
	Manufacturer = manufacturer;
}

public Date getDateOfManufacture() {
	return DateOfManufacture;
}

public void setDateOfManufacture(Date dateOfManufacture) {
	DateOfManufacture = dateOfManufacture;
}

public Date getExpiryDate() {
	return ExpiryDate;
}

public void setExpiryDate(Date expiryDate) {
	ExpiryDate = expiryDate;
}

@Override
public String toString() {
	return "Medicine [Id=" + Id + ", TypeOfMedicine=" + TypeOfMedicine + ", Name=" + Name + ", Price=" + Price
			+ ", Manufacturer=" + Manufacturer + ", DateOfManufacture=" + DateOfManufacture + ", ExpiryDate="
			+ ExpiryDate + "]";
}



}