package com.project.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.entity.Medicine;
import com.project.service.MedicineService;



@Controller
@RequestMapping("/medicine")
public class MedicineController 
{
	@RequestMapping("/main")
	public String displayMain(@RequestParam("UserName") String UserName,@RequestParam("Password") String Password,HttpServletRequest request,Model theModel)
	{
		if(UserName.equals("bhumi") && Password.equals("1234@bhumi"))
		{
		String userName=request.getParameter("UserName");
		String upperCaseUserName=userName.toUpperCase();
		theModel.addAttribute("uppercase",upperCaseUserName);
		return "medicine-list";
		}
		else
		{
			return "error";
		}
	}
	@Autowired
	MedicineService medicineService;
	@RequestMapping("/list")
	public String listMedicines(Model theModel) {
		List<Medicine> medicines =medicineService.getAllMedicines();
		theModel.addAttribute("medicines",medicines);
		System.out.println(medicines);//my cross checking im printing here
		return "medicine-list";
	}
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Medicine medicine=new Medicine();
		theModel.addAttribute("medicine",medicine);
		return "medicine-form";
	}
	@RequestMapping("/saveMedicine")
	public String saveMedicine(@ModelAttribute("medicine")Medicine theMedicine) {
		medicineService.saveMedicine(theMedicine);
	return "redirect:/medicine/list";
	}

	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("medicineId") int theId,Model theModel)
	{
				Medicine theMedicine=medicineService.getMedicine(theId);
			theModel.addAttribute("medicine",theMedicine);
			return "medicine-form";
	}
	
	@RequestMapping("/delete")
	public String deleteMedicine(@RequestParam("medicineId")int theId) {
		medicineService.deleteMedicine(theId);
		return "redirect:/medicine/list";
	}
	@RequestMapping("/findbyid")
	public String findByid(@RequestParam("search")String medicineId,Model theModel) 
	{
		Integer theId=Integer.parseInt(medicineId);
		Medicine medicine=medicineService.findMedicine(theId);
		theModel.addAttribute("medicine",medicine);
		return "search";
		
	}
}
