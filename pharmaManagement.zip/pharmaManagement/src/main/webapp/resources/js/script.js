function validateform(){  
var UserName=document.validation.UserName.value;  
var Password=document.validation.Password.value;  
  
if (UserName!="BhumiKrishnan"&&UserName=="null"){  
  alert("InValid UserName or not null");  
  return false;  
}
  else if(Password=="null"&&
		  Password.matches(".*[0-9]{1,}.*") &&
		  Password.matches(".*[@#$]{1,}.*") && 
		  Password.length()>=8 && Password.length()<=20){
	  alert("Password must be at least 8 characters long with atleast one " 
			  +"special chatracter"+"and one number and not null"); 
	  return false;  
  }
}